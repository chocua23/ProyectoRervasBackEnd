﻿
using BookingDestCore.Helpers;
using BookingDestCore.Interfaces;
using BookingDestCore.Models;
using Newtonsoft.Json;
using System.Data;
using static Dapper.SqlMapper;

namespace BookingDestCore.Repositories
{
    public class BookingRepository : IBookingRepository
    {
        private readonly IMethodsDatabase _methodsDatabase;
        private readonly string _connDatabase;        

        public BookingRepository(IMethodsDatabase methods, IConnection conn) {
            _methodsDatabase = methods;
            _connDatabase = conn.connectionString;
        }

        #region Interface Methods
        #region Booking
        /// <summary>
        /// Obtener la entidad Booking según su Id
        /// </summary>
        /// <param name="entity">Booking</param>
        /// <returns>Entity Booking or NULL</returns>
        /// <exception></exception>
        public async Task<Booking?> Get(Booking entity)
        {
            try
            {
                Validator.ValidateRequiredParameters(new dynamic[] { entity.Id });

                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@Booking_id", entity.Id);

                var Booking = await _methodsDatabase.GetEntities<Booking>(
                    _connDatabase,
                    "stPrGetBookingById",
                    CommandType.StoredProcedure,
                parameters);

                return Booking.FirstOrDefault();

            }
            catch (Exception)
            {
                throw;
            }
        }
        public async Task<int> GetSeatsAvailability(Booking entity)
        {
            try
            {
                Validator.ValidateRequiredParameters(new dynamic[] { entity.Id });

                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@destination", entity.Destination);
                parameters.Add("@bookingDate", entity.BookingDate);
                parameters.Add("@seats", entity.Seats);

                var Booking = await _methodsDatabase.ExecuteReader(
                    _connDatabase,
                    "strpGetAvailability",
                    CommandType.StoredProcedure,
                parameters);

                return int.Parse(Booking);

            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Obtener el listado de Bookings las cuales tendrán un paginado aplicado y podrán aplicarsele diferentes filtros
        /// </summary>
        /// <returns>Listado de Bookings</returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<IEnumerable<Booking>> GetAll(Booking entity, int pageSize, int currentPage)
        {
            try
            {
                //Validator.ValidateRequiredParameters(new dynamic[] { entity.Id });

                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@Booking_id", entity.Id);
                parameters.Add("@page_size", pageSize);
                parameters.Add("@current_page", currentPage);

                var Booking = await _methodsDatabase.GetEntities<Booking>(
                    _connDatabase,
                    "stPrGetBooking",
                    CommandType.StoredProcedure,
                parameters);

                return Booking;

            }

            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Método para crear un Booking 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<int> Create(Booking entity)
        {
            try
            {
                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@clientId", entity.ClientId);
                parameters.Add("@destination", entity.Destination);
                parameters.Add("@bookingDate", entity.BookingDate);
                parameters.Add("@seats", entity.Seats); 

                var newBooking = await _methodsDatabase.ExecuteReader(
                    _connDatabase,
                    "strpSaveBooking",
                    CommandType.StoredProcedure,
                    parameters);

                return string.IsNullOrEmpty(newBooking) ? 0 : int.Parse(newBooking);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Create(IEnumerable<Booking> entities)
        {
            try
            {
                var entitiesJson = JsonConvert.SerializeObject(entities);
                Dictionary<string, dynamic?> parameters = new();
                parameters.Add("@entitiesJson", entitiesJson);

                var newBooking = await _methodsDatabase.ExecuteNonQuery(
                    _connDatabase, "stPrCreateBookings", CommandType.StoredProcedure, parameters);

                return newBooking > 0 ? true : false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Método para actualizar un Booking según id
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> Update(Booking entity)
        {

            try
            {
                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@clientId", entity.ClientId);
                parameters.Add("@destination", entity.Destination);
                parameters.Add("@bookingDate", entity.BookingDate);
                parameters.Add("@seats", entity.Seats);

                var newBooking = await _methodsDatabase.ExecuteNonQuery(
                    _connDatabase,
                    "stPrUpdateBooking",
                    CommandType.StoredProcedure,
                    parameters);

                return newBooking > 0 ? true : false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Método para eliminar un Booking por id
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> Delete(Booking entity)
        {
            try
            {
                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@Booking_id", entity.Id);

                var deleteBooking = await _methodsDatabase.ExecuteNonQuery(
                    _connDatabase,
                    "stPrDeleteBooking",
                    CommandType.StoredProcedure,
                    parameters);

                return deleteBooking > 0 ? true : false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion
        #endregion

    }
}
