﻿
using BookingDestCore.Helpers;
using BookingDestCore.Interfaces;
using BookingDestCore.Models;
using Newtonsoft.Json;
using System.Data;
using static Dapper.SqlMapper;

namespace BookingDestCore.Repositories
{
    public class ClientRepository : IClientRepository
    {
        private readonly IMethodsDatabase _methodsDatabase;
        private readonly string _connDatabase;        

        public ClientRepository(IMethodsDatabase methods, IConnection conn) {
            _methodsDatabase = methods;
            _connDatabase = conn.connectionString;
        }

        #region Interface Methods
        #region Client
        /// <summary>
        /// Get Client by Id
        /// </summary>
        /// <param name="entity">Client</param>
        /// <returns>Entity Client or NULL</returns>
        /// <exception></exception>
        public async Task<Client?> Get(Client entity)
        {
            try
            {
                Validator.ValidateRequiredParameters(new dynamic[] { entity.Id });

                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@Client_id", entity.Id);

                var Client = await _methodsDatabase.GetEntities<Client>(
                    _connDatabase,
                    "stPrGetClientById",
                    CommandType.StoredProcedure,
                parameters);

                return Client.FirstOrDefault();

            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Obtener el listado de Clients las cuales tendrán un paginado aplicado y podrán aplicarsele diferentes filtros
        /// </summary>
        /// <returns>Listado de Clients</returns>
        /// <exception cref="NotImplementedException"></exception>
        public async Task<IEnumerable<Client>> GetAll(Client entity, int pageSize, int currentPage)
        {
            try
            {
                //Validator.ValidateRequiredParameters(new dynamic[] { entity.Id });

                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@Client_id", entity.Id);
                parameters.Add("@page_size", pageSize);
                parameters.Add("@current_page", currentPage);

                var Client = await _methodsDatabase.GetEntities<Client>(
                    _connDatabase,
                    "stPrGetClient",
                    CommandType.StoredProcedure,
                parameters);

                return Client;

            }

            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Método para crear un Client 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<int> Create(Client entity)
        {
            try
            {
                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@name", entity.Name);
                parameters.Add("@lastName", entity.LastName);
                parameters.Add("@email", entity.Email);
                parameters.Add("@phone", entity.Phone); 
                parameters.Add("@passportNumber", entity.PassportNumber);

                var newClient = await _methodsDatabase.ExecuteReader(
                    _connDatabase,
                    "strpClient",
                    CommandType.StoredProcedure,
                    parameters);

                return string.IsNullOrEmpty(newClient) ? 0 : int.Parse(newClient);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> Create(IEnumerable<Client> entities)
        {
            try
            {
                var entitiesJson = JsonConvert.SerializeObject(entities);
                Dictionary<string, dynamic?> parameters = new();
                parameters.Add("@entitiesJson", entitiesJson);

                var newClient = await _methodsDatabase.ExecuteNonQuery(
                    _connDatabase, "stPrCreateClients", CommandType.StoredProcedure, parameters);

                return newClient > 0 ? true : false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Método para actualizar un Client según id
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> Update(Client entity)
        {

            try
            {
                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@name", entity.Name);
                parameters.Add("@lastName", entity.LastName);
                parameters.Add("@email", entity.Email);
                parameters.Add("@phone", entity.Phone);

                var newClient = await _methodsDatabase.ExecuteNonQuery(
                    _connDatabase,
                    "stPrUpdateClient",
                    CommandType.StoredProcedure,
                    parameters);

                return newClient > 0 ? true : false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Método para eliminar un Client por id
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<bool> Delete(Client entity)
        {
            try
            {
                Dictionary<string, dynamic?> parameters = new Dictionary<string, dynamic?>();
                parameters.Add("@Client_id", entity.Id);

                var deleteClient = await _methodsDatabase.ExecuteNonQuery(
                    _connDatabase,
                    "stPrDeleteClient",
                    CommandType.StoredProcedure,
                    parameters);

                return deleteClient > 0 ? true : false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion
        #endregion

    }
}
