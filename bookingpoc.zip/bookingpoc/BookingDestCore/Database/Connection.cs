﻿using BookingDestCore.Interfaces;

namespace BookingDestCore.Database
{
    public class Connection : IConnection
    {
        public string connectionString { get; set; } = string.Empty;

    }
}
