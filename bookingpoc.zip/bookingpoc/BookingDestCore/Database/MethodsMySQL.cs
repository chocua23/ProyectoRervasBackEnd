﻿using BookingDestCore.Helpers;
using BookingDestCore.Interfaces;
using MySql.Data.MySqlClient;
using System.Data;
using System.Text;
using MySql.Data;
using Dapper;
using System.Linq;

namespace BookingDestCore.Database
{
    public class MethodsMySQL : IMethodsDatabase
    {
        public async Task<int> ExecuteNonQuery(string conn, string query, CommandType commandType, Dictionary<string, dynamic?> parameters)
        {
            MySqlConnection _conn = new MySqlConnection(conn);

            try
            {
                MySqlCommand _command = await CreateCommand(_conn, query, commandType, parameters!);

                _conn.Open();

                return _command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                _conn.Close();
            }
        }

        public async Task<string?> ExecuteScalar(string conn, string query, CommandType commandType, Dictionary<string, dynamic?> parameters)
        {
            MySqlConnection _conn = new MySqlConnection(conn);

            try
            {
                MySqlCommand _command = await CreateCommand(_conn, query, commandType, parameters!);

                _conn.Open();

                return _command.ExecuteScalar().ToString();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                _conn.Close();

            }
        }

        public async Task<string?> ExecuteReader(string conn, string query, CommandType commandType, Dictionary<string, dynamic?> parameters)
        {
            MySqlConnection _conn = new MySqlConnection(conn);

            try
            {
                var stringResult = new StringBuilder();

                MySqlCommand _command = await CreateCommand(_conn, query, commandType, parameters!);

                _conn.Open();

                var reader = _command.ExecuteReader();
                while (reader.Read())
                {
                    stringResult.Append(reader.GetValue(0).ToString());
                }

                return stringResult.ToString();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                _conn.Close();
            }
        }

        public async Task<IEnumerable<C>> GetEntities<C>(string conn, string query, CommandType commandType, Dictionary<string, dynamic?> parameters)
        {
            using (MySqlConnection _conn = new MySqlConnection(conn))
            {
                try
                {
                    await _conn.OpenAsync();

                    CommandDefinition commandDefinition = new CommandDefinition(query, parameters, null, null, commandType, CommandFlags.Buffered, CancellationToken.None);
                    var results = await _conn.QueryAsync<C>(commandDefinition);
                    return results;
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        public async Task<DataSet> GetDataSet(string conn, string query, CommandType commandType, Dictionary<string, dynamic?> parameters)
        {
            MySqlConnection _conn = new MySqlConnection(conn);

            try
            {
                MySqlCommand _command = await CreateCommand(_conn, query, commandType, parameters!);

                MySqlDataAdapter adap = new MySqlDataAdapter();
                DataSet ds = new DataSet();

                adap = new MySqlDataAdapter(_command);
                adap.Fill(ds);

                return ds;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                _conn.Close();
            }
        }

        private Task<MySqlCommand> CreateCommand(IDbConnection conn, string query, CommandType commandType, Dictionary<string, dynamic?> parameters)
        {
            MySqlCommand _command = new MySqlCommand(query, (MySqlConnection)conn)
            {
                CommandType = commandType,
                CommandTimeout = 120

            };

            _command.Parameters.Clear();
            if (parameters != null)
            {
                foreach (var parameter in parameters)
                {
                    _command.Parameters.AddWithValue(parameter.Key, parameter.Value);
                }
            }
            return Task.FromResult(_command);
        }
    }
}
