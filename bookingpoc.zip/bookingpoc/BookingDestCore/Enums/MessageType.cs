﻿namespace BookingDestCore.Enums
{
    public enum MessageType : byte
    {
        Create = 1,
        Update = 2,
        Delete = 3,
        Error = 4,
        NotFound = 5,
    }
}
