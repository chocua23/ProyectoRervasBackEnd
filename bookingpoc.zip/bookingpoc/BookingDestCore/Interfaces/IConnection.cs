﻿namespace BookingDestCore.Interfaces
{
    public interface IConnection
    {
        string connectionString { get; set; }
    }
}
