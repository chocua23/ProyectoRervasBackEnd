﻿using BookingDestCore.Models;

namespace BookingDestCore.Interfaces
{
    public interface IBookingRepository : IRepository<Booking>
    {
        Task<bool> Create(IEnumerable<Booking> entities);
        Task<int> GetSeatsAvailability(Booking entity);
    }
}