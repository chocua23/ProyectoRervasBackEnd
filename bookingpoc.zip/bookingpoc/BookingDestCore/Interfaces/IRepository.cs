﻿namespace BookingDestCore.Interfaces
{
    public interface IRepository<T> where T : class
    {
        #region Properties
        //IDbConnection _connDatabase { get; set; }
        //IMethodsDatabase _methodsDatabase { get; set; }
        #endregion

        #region Methods
        Task<T?> Get(T entity);
        Task<IEnumerable<T>> GetAll(T entity, int pageSize, int currentPage);
        Task<int> Create (T entity);
        Task<bool> Update (T entity);
        Task<bool> Delete (T entity);
        #endregion
    }
}
