﻿using System.Data;

namespace BookingDestCore.Interfaces
{
    public interface IMethodsDatabase
    {
        Task<int> ExecuteNonQuery(string connection, string query, CommandType commandType, Dictionary<string, dynamic?> parameters);
        Task<string?> ExecuteScalar(string connection, string query, CommandType commandType, Dictionary<string, dynamic?> parameters);
        Task<string?> ExecuteReader(string conn, string query, CommandType commandType, Dictionary<string, dynamic?> parameters);
        Task<IEnumerable<C>> GetEntities<C>(string connection, string query, CommandType commandType, Dictionary<string, dynamic?> parameters);
        Task<DataSet> GetDataSet(string conn, string query, CommandType commandType, Dictionary<string, dynamic?> parameters);
    }   
}
