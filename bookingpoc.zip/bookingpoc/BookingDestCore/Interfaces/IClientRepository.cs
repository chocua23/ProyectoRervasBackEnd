﻿using BookingDestCore.Models;

namespace BookingDestCore.Interfaces
{
    public interface IClientRepository:IRepository<Client>
    {
        Task<bool> Create(IEnumerable<Client> entities);
    }
}