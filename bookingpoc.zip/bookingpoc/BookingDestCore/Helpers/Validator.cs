﻿namespace BookingDestCore.Helpers
{
    public class Validator
    {
        /// <summary>
        /// Validador de parametros ingresados a un API, para comprobar que parametros requeridos no sean nulos o esten vacíos
        /// </summary>
        /// <param name="parameters">Ingreso de parametros de diferente tipo</param>
        /// <exception cref="Exception"></exception>
        public static void ValidateRequiredParameters(dynamic[] parameters) // probar método el lunes
        {
            foreach (var p in parameters)
            {
                if (p is null)
                    throw new Exception("Al URI le falta un parámetro de cadena de consulta obligatorio");
                else if (string.IsNullOrWhiteSpace(p.ToString()))
                    throw new Exception("Al URI le falta un valor de parámetro de cadena de consulta obligatorio");
            }
        }
    }
}