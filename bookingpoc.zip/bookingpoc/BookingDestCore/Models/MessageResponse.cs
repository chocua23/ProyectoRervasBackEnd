﻿using BookingDestCore.Enums;
using System.Net;

namespace BookingDestCore.Models
{
    public class MessageResponse
    {
        public string Code { get; set; } = string.Empty;
        public string Message { get; set; } = string.Empty;
        public string Reason { get; set; } = string.Empty;
        public int Status { get; set; }
        public int Id { get; set; } = 0;
        public DateTime Timestamp { get; set; }
        /// <summary>
        /// Tipos de mensajes
        /// 1 = Create
        /// 2 = Update
        /// 3 = Delete
        /// 4 = Error
        /// 5 = NotFound
        /// </summary>
        public Dictionary<MessageType, string> messages = new Dictionary<MessageType, string>() {
            {MessageType.Create, "La solicitud se cumplió y el servidor creó el recurso"},
            {MessageType.Update, "La solicitud se cumplió y el servidor actualizo el recurso"},
            {MessageType.Delete, "La solicitud se cumplió y el servidor elimino el recurso"},
            {MessageType.Error, "Error en la solicitud, no se puedo llevar a cabo la acción"},
            {MessageType.NotFound, "La solicitud se cumplió, pero el servidor no encontro resultados"}
        };

        

        /// <summary>
        /// Metodo constructor
        ///
        /// </summary>
        /// <param name="state">bool</param>
        /// <param name="type">i</param>
        public MessageResponse(MessageType type, int id, bool state = true) {
            Code = (state) ? HttpStatusCode.Accepted.ToString() : HttpStatusCode.BadRequest.ToString();
            Message = (state) ? messages[type] : messages[MessageType.Error];
            Status = state ? 200 : 400;
            Reason = state ? "Petición aceptada" : "Petición rechazada";   
            Timestamp= DateTime.Now;
            Id = id;
        }
    }
}
