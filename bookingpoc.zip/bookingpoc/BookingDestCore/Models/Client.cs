﻿using System.Text.Json.Serialization;

namespace BookingDestCore.Models
{
    public class Client
    {
        /// <summary>
        /// Client class
        /// </summary>
        public int Id { get; set; }
        public string PassportNumber { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string? Email { get; set; } = string.Empty;
        public string? Phone { get; set; } = string.Empty;
    }
}
