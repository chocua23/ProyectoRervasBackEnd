﻿using System.Text.Json.Serialization;

namespace BookingDestCore.Models
{
    public class Booking
    {
        /// <summary>
        /// Client class
        /// </summary>
        public int Id { get; set; }
        public DateTime BookingDate { get; set; } 
        public int Seats { get; set; } = 0;
        public string Destination { get; set; } = string.Empty;
        public int ClientId { get; set; }
    }
}
