﻿using Microsoft.AspNetCore.Mvc;
using BookingDestCore.Models;
using BookingDestCore.Interfaces;
using BookingDestCore.Enums;
using Microsoft.AspNetCore.Http;

namespace BookingDes.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class BookingController : Controller
    {
        private readonly IBookingRepository _bookingRepository;
        /// <summary>
        /// Booking repository
        /// </summary>
        /// <param name="bookingRepository"></param>
        public BookingController(IBookingRepository bookingRepository)
        {
            _bookingRepository = bookingRepository;
        }
        /// <summary>
        /// Create a booking
        /// </summary>
        /// <param name="booking"></param>
        /// <returns></returns>
        [HttpPost()]
        [Produces("application/json")]
        public async Task<IActionResult> Post([FromBody] Booking booking)
        {
            try
            {
                var newBooking = await _bookingRepository.Create(booking);
                var res = new MessageResponse(MessageType.Create, newBooking,true);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }
        /// <summary>
        /// Get seats availability 
        /// </summary>
        /// <param name="booking"></param>
        /// <returns></returns>
        [HttpGet("SeatsAvailability")]
        public async Task<IActionResult> GetSeatsAvailability([FromBody] Booking booking)
        {
            try
            {
                var newBooking = await _bookingRepository.GetSeatsAvailability(booking);
                var res = new MessageResponse(MessageType.Create, newBooking, true);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }
    }
}
