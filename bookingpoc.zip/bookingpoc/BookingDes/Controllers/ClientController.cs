﻿using Microsoft.AspNetCore.Mvc;
using BookingDestCore.Models;
using BookingDestCore.Interfaces;
using BookingDestCore.Enums;
using Microsoft.AspNetCore.Http;

namespace BookingDes.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class ClientController : Controller
    {
        private readonly IClientRepository _clientRepository;
        /// <summary>
        /// Client controller
        /// </summary>
        /// <param name="clientRepository"></param>
        public ClientController(IClientRepository clientRepository)
        {
            _clientRepository = clientRepository;
        }
        /// <summary>
        /// Create a client
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        [HttpPost()]
        [Produces("application/json")]
        public async Task<IActionResult> Post([FromBody] Client client)
        {
            try
            {
                var newClient = await _clientRepository.Create(client);
                var res = new MessageResponse(MessageType.Create, newClient, true);
                return Ok(res);
            }
            catch (Exception ex)
            {
                return Problem(ex.Message);
            }
        }
    }
}
