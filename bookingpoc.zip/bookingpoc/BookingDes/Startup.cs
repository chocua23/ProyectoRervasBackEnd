﻿using BookingDestCore.Database;
using BookingDestCore.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.OpenApi.Models;
using System.Configuration;
using System.Reflection;
using BookingDes.Models;

namespace BookingDes
{
    public class Startup
    {
        public static string _connectionString { get; private set; } = string.Empty;
        public static string _corsPolicy = "CorsPolicy";
        public IConfiguration Configuration { get; }
        private readonly OpenApiInfo openApiInfo = new OpenApiInfo { Title = "API Booking", Version = "v1" };
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            _connectionString = Environment.GetEnvironmentVariable("BookingConn", EnvironmentVariableTarget.Process)!;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();


            services.AddSwaggerGen(options => {
                var xmlFileName = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml"; //obtiene el archivo de comentarios xml
                options.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, xmlFileName));
            });

            //DI
            services.AddSingleton<IConnection, Connection>(provider => new Connection() { connectionString = _connectionString });
            services.AddSingleton<IMethodsDatabase, MethodsMySQL>();
            services.AddRepositories();

            services.AddCors(options =>
            {
                options.AddPolicy(_corsPolicy, builder =>
                {
                    builder.AllowAnyOrigin();
                });
            });
        }
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseStatusCodePagesWithRedirects("error/{0}");
            }

            app.UseStatusCodePagesWithRedirects("/error/handler/{0}");
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.),
            // specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", openApiInfo.Title);
            });

            app.UseRouting();

            app.UseCors(_corsPolicy);

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers()
                .RequireCors(_corsPolicy);
            });
        }
    }

}
