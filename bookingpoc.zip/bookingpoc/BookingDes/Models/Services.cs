﻿using BookingDestCore.Interfaces;
using BookingDestCore.Repositories;
using System.Configuration;

namespace BookingDes.Models
{
    public static class Services
    {
        public static IServiceCollection AddRepositories(this IServiceCollection services)
        {
            services.AddScoped<IClientRepository, ClientRepository>();
            services.AddScoped<IBookingRepository, BookingRepository>();
            return services;
        }
    }
}